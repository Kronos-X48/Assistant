from server.contrib import admin

# Register your models here.
