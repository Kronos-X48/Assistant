default_app_config = 'server.contrib.admindocs.apps.AdminDocsConfig'
