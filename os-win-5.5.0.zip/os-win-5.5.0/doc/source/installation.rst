============
Installation
============

At the command line::

    $ pip install os-win

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv os-win
    $ pip install os-win
