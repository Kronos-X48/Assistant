"""os_sys.__init__ does not have this big file any more now you need to call from os_sys.modules import * """
