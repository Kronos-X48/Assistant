============================
Os-win Configuration Options
============================

The following is a sample os-win configuration for adaptation and use.

The sample configuration can also be viewed in :download:`file from
</_static/os-win.conf.sample>`.

.. important::

   The sample configuration file is auto-generated from os-win when this
   documentation is built. You must ensure your version of os-win matches the
   version of this documentation.

.. literalinclude:: /_static/os-win.conf.sample
