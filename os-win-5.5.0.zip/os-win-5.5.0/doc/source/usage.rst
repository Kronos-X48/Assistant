=====
Usage
=====

To use os-win in a project::

    import os_win
