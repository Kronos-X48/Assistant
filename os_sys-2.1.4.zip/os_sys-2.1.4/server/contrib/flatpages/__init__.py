default_app_config = 'server.contrib.flatpages.apps.FlatPagesConfig'
